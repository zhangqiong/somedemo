
$(window).load(function(){
       function arrange(){
              var li_width=336,col;
              if($(window).outerWidth()-40<li_width){
                li_width=$(window).outerWidth();
                col=1;
              }else{
                col=Math.floor(($(window).outerWidth()-40)/li_width);

              }
              if(col>4)col=4;
              $('#auto-loop').css('width',col*li_width);
              var i=0,left,top,$last_li;

              $('#auto-loop li').each(function(){
                    left=i%col*li_width;
                    $(this).css('left',left+'px');
                    if(i<col){
                            $(this).css('top','0');
                    }else{
                     $last_li=$(this).siblings().eq(i-col);
                     top=$last_li.position().top+$last_li.outerHeight(true)+'px';
                     $(this).css('top',top);
                    }
                    i++;
                    $(this).css('opacity','1');
              });

       }



       function loadImg(sum_once){
              var length=infos.length,i,htmlTxt="";
              infos.reverse();
              
              for(i=show_count;i<show_count+sum_once && i<length;i++){
                     // htmlTxt+='<li><a href="" data-to="'+(i+1)+'">'+(i+1)+'</a></li>';
                     htmlTxt+='<li data-src="images/'+infos[i].url+'"> <a href="#"><img src="images/'+infos[i].url+'" /><span class="introduction">'+infos[i].title+infos[i].introduction+'</span></a> </li>';
              }
              
              $('#auto-loop').append($(htmlTxt));
              $('img').load(arrange);
              $("#auto-loop").lightGallery({
                                   loop:true,
                                   auto:false,
                                   pause:4000,
                                   from:show_count
              });
              show_count+=sum_once;
       }
       var infos;
       var show_count=0;
	// alert("loaded");
       $('#urls').load("images/titleAfter-original.json",function(){
              infos=JSON.parse($('#urls').text()) ;
              $(window).resize(arrange);
              loadImg(30);
              
              

       });
       $(window).scroll(function(){
              if($(document).outerHeight()-$(document).scrollTop()<2*$(window).outerHeight()){
                     loadImg(30);
                     
              }
       });
});

       	